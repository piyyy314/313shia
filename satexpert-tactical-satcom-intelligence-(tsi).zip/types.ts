
export interface Coordinates {
  lat: number;
  lng: number;
}

export type SatelliteStatus = 'active' | 'offline' | 'maintenance' | 'decommissioned';
export type WeatherCondition = 'CLEAR' | 'OVERCAST' | 'LIGHT_RAIN' | 'HEAVY_STORM';

export interface Satellite {
  id: string;
  name: string;
  longitude: number; // Positive for East, Negative for West
  orbitalSlot: string;
  operator?: string;
  apogee?: number;
  perigee?: number;
  inclination?: number;
  velocity?: number;
  status?: SatelliteStatus;
  frequencies?: string[]; // e.g., ["Ka-Band", "Ku-Band"]
}

export interface LookAngles {
  azimuth: number;
  elevation: number;
  skew: number;
  distance: number; // km;
}

export interface LinkBudgetParams {
  uplinkFreq: number; // GHz
  downlinkFreq: number; // GHz
  txPower: number; // dBW
  antSize: number; // meters
  efficiency: number; // %
  lnbNoiseTemp: number; // K
  rainFade: number; // dB
}

export interface LinkBudgetResults {
  fspl: number; // dB
  antGain: number; // dBi
  gt: number; // dB/K
  ebNo: number; // dB
  ber: string; // Scientific notation string
}

export interface TroubleshootingLog {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isCode?: boolean;
  imageUrl?: string;
}

export type MainView = 'tactical' | 'intelligence' | 'interception' | 'media' | 'live' | 'calculations' | 'news' | 'darklink' | 'lookup';
export type SecurityTab = 'overview' | 'assessment' | 'modem' | 'attack' | 'detection' | 'hardening' | 'codes' | 'scripts' | 'intel' | 'stealth' | 'quantum' | 'wargames' | 'sniffer' | 'aegis' | 'audit';
