
import * as React from 'react';
import { useState, useEffect, useRef } from 'react';

interface DarkLinkProps {
    isActive: boolean;
    setIsActive: (val: boolean) => void;
}

export const DarkLink: React.FC<DarkLinkProps> = ({ isActive, setIsActive }) => {
    const [localStatus, setLocalStatus] = useState<"DISCONNECTED" | "CONNECTING" | "ERROR">("DISCONNECTED");
    const [error, setError] = useState<string | null>(null);
    const [port, setPort] = useState<any>(null);
    const [logs, setLogs] = useState<{timestamp: string, msg: string}[]>([]);

    const status = isActive ? "ACTIVE" : localStatus;

    const addLog = (msg: string) => {
        setLogs(prev => [{
            timestamp: new Date().toLocaleTimeString([], { hour12: false }),
            msg
        }, ...prev].slice(0, 50));
    };

    const [isSimulated, setIsSimulated] = useState(false);

    const activateDarkLink = async (simulate = false) => {
        setLocalStatus("CONNECTING");
        setError(null);
        addLog(simulate ? "INITIATING VIRTUAL DARK-LINK [SIMULATION]..." : "INITIATING DARK-LINK PROTOCOL...");
        
        if (simulate) {
            setIsSimulated(true);
            setTimeout(() => {
                setIsActive(true);
                addLog("VIRTUAL MESH INITIALIZED. SIMULATED BYPASS ACTIVE.");
                addLog("GATEWAY: VIRTUAL_NODE_LOGIC.ALPHA");
            }, 1000);
            return;
        }

        try {
            // Check if Web Serial is supported
            if (!('serial' in navigator)) {
                throw new Error("WEB_SERIAL_NOT_SUPPORTED");
            }

            // Request access to the LoRa/Meshtastic device via USB
            const selectedPort = await (navigator as any).serial.requestPort();
            await selectedPort.open({ baudRate: 115200 });
            
            setPort(selectedPort);
            setIsActive(true);
            addLog("MESH-NET INITIALIZED. BYPASSING ISP.");
            addLog("HARDWARE_HANDSHAKE: SUCCESS");
        } catch (e: any) {
            console.error("Off-Grid Hardware connection error.", e);
            setLocalStatus("ERROR");
            if (e.name === 'NotFoundError') {
                setError("HARDWARE_NOT_FOUND: No device selected.");
                addLog("ERROR: DEVICE_SELECTION_CANCELLED");
            } else if (e.name === 'SecurityError' || e.message.includes('permissions policy')) {
                setError("PERMISSION_DENIED: Serial access blocked by system policy.");
                addLog("ERROR: PERMISSION_SECURITY_VIOLATION");
            } else if (e.message === "WEB_SERIAL_NOT_SUPPORTED") {
                setError("BROWSER_UNSUPPORTED: Web Serial API not available.");
                addLog("ERROR: API_UNAVAILABLE");
            } else {
                setError("CONNECTION_FAILURE: Off-grid hardware not detected or busy.");
                addLog("ERROR: UPLINK_TIMEOUT");
            }
        }
    };

    const disconnect = async () => {
        if (port) {
            try {
                await port.close();
            } catch (e) {
                console.error("Error closing port", e);
            }
            setPort(null);
        }
        setIsActive(false);
        setIsSimulated(false);
        setLocalStatus("DISCONNECTED");
        addLog("DARK-LINK DEACTIVATED. RETURNING TO STANDARD COMMS.");
    };

    const [message, setMessage] = useState("");

    const sendMessage = async () => {
        if (!message) return;
        addLog(`TX_SEND: ${message}`);
        setMessage("");

        if (isSimulated) {
            setTimeout(() => {
                const responses = [
                    "VIRTUAL_MESH: ACKNOWLEDGEMENT_RECEIVED",
                    "ALPHA_NODE: PARITY_MATCH_CONFIRMED",
                    "GHOST_NET: ROUTING_PACKET_THROUGH_P2P_LAYER",
                    "REPLY_FROM_0x42: ROLLING_CODE_ACCEPTED"
                ];
                addLog(`RX_RECV: ${responses[Math.floor(Math.random() * responses.length)]}`);
            }, 800);
        } else if (port) {
            // Real Serial transmission would go here
            try {
                const encoder = new TextEncoder();
                const writer = port.writable.getWriter();
                await writer.write(encoder.encode(message + "\n"));
                writer.releaseLock();
                addLog("TX_BUFFER: FLUSHED_TO_HARDWARE");
            } catch (e) {
                addLog("TX_ERROR: HARDWARE_LINK_INTERRUPTED");
            }
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500 pb-12">
            <header className="flex items-center justify-between mb-8">
                <div>
                    <h2 className="text-2xl font-black text-white uppercase tracking-tight flex items-center">
                        <span className="mr-3 p-2 bg-red-500/10 rounded-lg border border-red-500/20">📡</span> Dark <span className="text-red-500 ml-2">Link</span>
                    </h2>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mt-1 ml-1">Off-Grid Mesh Networking // Meshtastic Integration</p>
                </div>
                <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${status === 'ACTIVE' ? 'bg-red-500 animate-pulse' : 'bg-slate-700'}`}></div>
                    <span className={`text-[10px] font-black uppercase tracking-widest ${status === 'ACTIVE' ? 'text-red-500' : 'text-slate-500'}`}>
                        {status === 'ACTIVE' ? 'OFF-GRID / MESH ACTIVE' : 'STANDARD_LINK'}
                    </span>
                </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-4 space-y-6">
                    <div className="glass p-6 rounded-3xl border-slate-800 bg-slate-950/40">
                        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Hardware Interface</h3>
                        
                        <div className="space-y-4">
                            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
                                <div className="flex items-center justify-between">
                                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Protocol</span>
                                    <span className="text-[10px] font-bold text-white mono">LoRa / Meshtastic</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Baud Rate</span>
                                    <span className="text-[10px] font-bold text-cyan-400 mono">115200</span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Encryption</span>
                                    <span className="text-[10px] font-bold text-green-400 mono">AES-256-GCM</span>
                                </div>
                            </div>

                            {error && (
                                <div className="p-4 bg-red-900/20 border border-red-500/40 rounded-xl space-y-3">
                                    <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">{error}</p>
                                    <button 
                                        onClick={() => activateDarkLink(true)}
                                        className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-[9px] font-black text-white uppercase tracking-widest rounded-lg border border-slate-700"
                                    >
                                        Bypass with Simulated Mode
                                    </button>
                                </div>
                            )}

                            {status !== 'ACTIVE' ? (
                                <div className="space-y-4">
                                    <button 
                                        onClick={() => activateDarkLink(false)} 
                                        disabled={status === 'CONNECTING'}
                                        className="w-full bg-red-600 hover:bg-red-500 disabled:opacity-30 text-white text-[10px] font-black py-4 rounded-2xl uppercase tracking-[0.2em] shadow-lg shadow-red-600/20 transition-all active:scale-95"
                                    >
                                        {status === 'CONNECTING' ? 'INITIALIZING_HARDWARE...' : 'ACTIVATE DARK-LINK'}
                                    </button>
                                    {!error && (
                                        <button 
                                            onClick={() => activateDarkLink(true)}
                                            className="w-full text-slate-500 hover:text-slate-300 text-[8px] font-black uppercase tracking-widest py-1 transition-colors"
                                        >
                                            Enter Simulated Bypass Mode
                                        </button>
                                    )}
                                </div>
                            ) : (
                                <button 
                                    onClick={disconnect} 
                                    className="w-full bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-black py-4 rounded-2xl uppercase tracking-[0.2em] border border-slate-700 transition-all active:scale-95"
                                >
                                    DEACTIVATE LINK
                                </button>
                            )}
                        </div>
                    </div>

                    <div className="glass p-6 rounded-3xl border-slate-800 bg-slate-950/40">
                        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">System Status</h3>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between text-[9px] font-bold mono text-slate-500">
                                <span>Signal Strength</span>
                                <span className={status === 'ACTIVE' ? 'text-green-400' : 'text-slate-700'}>{status === 'ACTIVE' ? '-84 dBm' : 'N/A'}</span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                                <div className={`h-full transition-all duration-1000 ${status === 'ACTIVE' ? 'bg-green-500 w-[70%]' : 'w-0'}`}></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-8">
                    <div className="glass rounded-3xl border-slate-800 bg-slate-950/60 h-full min-h-[500px] flex flex-col overflow-hidden">
                        <div className="p-4 border-b border-slate-800 bg-slate-900/40 flex items-center justify-between">
                            <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Mesh_Terminal // Secure_Node_Output</span>
                            <div className="flex space-x-1">
                                <div className={`w-1.5 h-1.5 rounded-full ${status === 'ACTIVE' ? 'bg-red-500 animate-pulse' : 'bg-slate-800'}`}></div>
                                <div className="w-1.5 h-1.5 rounded-full bg-slate-800"></div>
                            </div>
                        </div>
                        
                        <div className="flex-grow overflow-y-auto p-6 space-y-3 bg-slate-950/40 scrollbar-hide">
                            {logs.length > 0 ? (
                                logs.map((log, i) => (
                                    <div key={i} className="text-[11px] mono flex space-x-4 animate-in fade-in slide-in-from-left-2">
                                        <span className="text-slate-600 shrink-0">[{log.timestamp}]</span>
                                        <span className={`${log.msg.includes('ERROR') ? 'text-red-400' : log.msg.includes('SUCCESS') || log.msg.includes('ACTIVE') ? 'text-green-400' : 'text-slate-300'}`}>
                                            {log.msg}
                                        </span>
                                    </div>
                                ))
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-20">
                                    <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Awaiting Hardware Handshake</span>
                                </div>
                            )}
                        </div>

                        {status === 'ACTIVE' && (
                            <div className="p-4 bg-slate-900/60 border-t border-slate-800">
                                <form 
                                    onSubmit={(e) => { e.preventDefault(); sendMessage(); }}
                                    className="flex space-x-2"
                                >
                                    <input 
                                        type="text" 
                                        value={message}
                                        onChange={(e) => setMessage(e.target.value)}
                                        placeholder="SEND MESH MESSAGE..." 
                                        className="flex-grow bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[10px] text-white mono outline-none focus:border-red-500"
                                    />
                                    <button 
                                        type="submit"
                                        className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                                    >
                                        SEND
                                    </button>
                                </form>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
