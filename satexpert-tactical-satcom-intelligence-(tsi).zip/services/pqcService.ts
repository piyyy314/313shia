
import { keypair, verify, Keys } from 'pqc-dilithium';

export interface PQCKeyPair {
    publicKey: Uint8Array;
    secretKey: Uint8Array;
    _keysInstance?: Keys; // Keep the instance for signing if needed
}

/**
 * SatExpert PQC Service
 * Implements NIST-standardized ML-DSA (Dilithium) for tactical signing.
 */
export class PQCService {
    /**
     * Generates a bit-packed PQC keypair (ML-DSA-65 equivalent).
     */
    static generateKeypair(): PQCKeyPair {
        try {
            const keys = keypair();
            return {
                publicKey: keys.pubkey,
                secretKey: keys.secret,
                _keysInstance: keys
            };
        } catch (error) {
            console.error("PQC_KEYGEN_FAILURE", error);
            throw new Error("FAILED_TO_GENERATE_PQC_KEYS");
        }
    }

    /**
     * Signs a message using the secret key.
     * Note: This library requires the Keys instance to sign.
     */
    static sign(message: string, keysInstance: Keys): Uint8Array {
        try {
            const msgUint8 = new TextEncoder().encode(message);
            const signature = keysInstance.sign(msgUint8);
            return signature;
        } catch (error) {
            console.error("PQC_SIGN_FAILURE", error);
            throw new Error("FAILED_TO_SIGN_PAYLOAD");
        }
    }

    /**
     * Verifies a signature against a message and public key.
     */
    static verify(message: string, signature: Uint8Array, publicKey: Uint8Array): boolean {
        try {
            const msgUint8 = new TextEncoder().encode(message);
            const isValid = verify(signature, msgUint8, publicKey);
            return isValid;
        } catch (error) {
            console.error("PQC_VERIFY_FAILURE", error);
            return false;
        }
    }

    /**
     * Helper to convert Uint8Array to hex for display
     */
    static toHex(arr: Uint8Array): string {
        return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
    }
}
