
import * as React from 'react';
import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Layout } from './components/Layout.tsx';
import { LookAngleCard } from './components/LookAngleCard.tsx';
import { AITechnician } from './components/AITechnician.tsx';
import { SecurityTools } from './components/SecurityTools.tsx';
import { LinkBudgetCalculator } from './components/LinkBudgetCalculator.tsx';
import { SignalVisualizer } from './components/SignalVisualizer.tsx';
import { TacticalHUD } from './components/TacticalHUD.tsx';
import { TacticalMap } from './components/TacticalMap.tsx';
import { RSSReader } from './components/RSSReader.tsx';
import { TelemetryPulse } from './components/TelemetryPulse.tsx';
import { SignalInterceptor } from './components/SignalInterceptor.tsx';
import { MediaForge } from './components/MediaForge.tsx';
import { LiveComms } from './components/LiveComms.tsx';
import { TerrainObstruction } from './components/TerrainObstruction.tsx';
import { DarkLink } from './components/DarkLink.tsx';
import { SatelliteLookup } from './components/SatelliteLookup.tsx';
import { Coordinates, Satellite, LookAngles, WeatherCondition, MainView, SatelliteStatus } from './types.ts';
import { COMMON_SATELLITES } from './constants.ts';
import { calculateLookAngles } from './utils/geoUtils.ts';

const STORAGE_KEY = 'satexpert_tactical_v5';
const STEALTH_STORAGE_KEY = 'satexpert_stealth_mode';
const EVENT_LOG_STORAGE_KEY = 'satexpert_event_logs';

interface TacticalEvent {
  id: string;
  timestamp: string;
  satName: string;
  satId: string;
  status: SatelliteStatus | 'CRITICAL' | 'BREACH';
  detail: string;
}

export const App: React.FC = () => {
  const [satellites, setSatellites] = useState<Satellite[]>(COMMON_SATELLITES);
  const [userLoc, setUserLoc] = useState<Coordinates>({ lat: 51.5074, lng: -0.1278 });
  const [selectedSat, setSelectedSat] = useState<Satellite>(satellites[0]);
  const [lookAngles, setLookAngles] = useState<LookAngles | null>(null);
  const [view, setView] = useState<MainView>('tactical');
  const [defcon, setDefcon] = useState<number>(5);
  const [isTracking, setIsTracking] = useState<boolean>(false);
  const [weather, setWeather] = useState<WeatherCondition>('CLEAR');
  const [isJamming, setIsJamming] = useState<boolean>(false);
  const [jammingPower, setJammingPower] = useState<number>(50);
  const [isStealthMode, setIsStealthMode] = useState<boolean>(false);
  const [isNeuralCleaning, setIsNeuralCleaning] = useState(false);
  const [isDarkLinkActive, setIsDarkLinkActive] = useState(false);
  
  // Global Event Log State
  const [eventLogs, setEventLogs] = useState<TacticalEvent[]>([]);
  const [hasNewLogs, setHasNewLogs] = useState(false);

  const isFirstMount = useRef(true);

  const addMissionLog = useCallback((detail: string, status: TacticalEvent['status'] = 'active') => {
    const newEvent: TacticalEvent = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString([], { hour12: false }),
      satName: selectedSat.name,
      satId: selectedSat.id,
      status: status,
      detail: detail
    };
    setEventLogs(prev => [newEvent, ...prev].slice(0, 50));
    setHasNewLogs(true);
  }, [selectedSat]);

  // Source of Truth Telemetry logic
  const telemetry = useMemo(() => {
    let snr = 16.0;
    let rxPower = -42.0;
    let packetLoss = 0.00;
    let bucTemp = 45.0;

    if (weather === 'OVERCAST') { snr -= 2.0; rxPower -= 1.5; }
    else if (weather === 'LIGHT_RAIN') { snr -= 5.0; rxPower -= 3.5; packetLoss += 0.8; }
    else if (weather === 'HEAVY_STORM') { snr -= 14.0; rxPower -= 12.0; packetLoss += 12.5; }

    if (isJamming) {
      snr -= (jammingPower / 5); 
      packetLoss += (jammingPower / 2);
      rxPower += (jammingPower / 10);
      bucTemp += (jammingPower / 15);
    }

    if (isNeuralCleaning) {
      snr += 4.5;
      packetLoss *= 0.2;
    }
    
    if (defcon <= 2) bucTemp += 8.0;

    if (isStealthMode) {
      snr = 20.0; rxPower = -30.0; packetLoss = 0.00; bucTemp = 35.0;
    }

    return {
      snr: Math.max(0, snr + (Math.random() - 0.5)).toFixed(2),
      rxPower: (rxPower + (Math.random() - 0.5)).toFixed(1),
      bucTemp: (bucTemp + (Math.random() - 0.5)).toFixed(1),
      packetLoss: Math.min(100, packetLoss + (Math.random() * 0.2)).toFixed(2),
      status: snr > 10 ? "NOMINAL" : (snr > 4 ? "DEGRADED" : "CRITICAL")
    };
  }, [weather, isJamming, jammingPower, defcon, isStealthMode, isNeuralCleaning]);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.loc) setUserLoc(parsed.loc);
      if (parsed.satId) {
        const sat = satellites.find(s => s.id === parsed.satId);
        if (sat) setSelectedSat(sat);
      }
      setDefcon(parsed.defcon || 5);
    }
    const savedStealth = localStorage.getItem(STEALTH_STORAGE_KEY);
    if (savedStealth !== null) setIsStealthMode(JSON.parse(savedStealth));

    const savedLogs = localStorage.getItem(EVENT_LOG_STORAGE_KEY);
    if (savedLogs) setEventLogs(JSON.parse(savedLogs));

    isFirstMount.current = false;
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ loc: userLoc, satId: selectedSat.id, defcon }));
  }, [userLoc, selectedSat, defcon]);

  useEffect(() => {
    if (!isFirstMount.current) localStorage.setItem(STEALTH_STORAGE_KEY, JSON.stringify(isStealthMode));
  }, [isStealthMode]);

  useEffect(() => {
    localStorage.setItem(EVENT_LOG_STORAGE_KEY, JSON.stringify(eventLogs));
  }, [eventLogs]);

  useEffect(() => {
    setLookAngles(calculateLookAngles(userLoc, selectedSat.longitude));
  }, [userLoc, selectedSat]);

  return (
    <div className={`crt-screen min-h-screen ${(!isStealthMode && (isJamming || defcon === 1)) ? 'crt-distorted' : ''}`}>
      <Layout isStealthMode={isStealthMode} setIsStealthMode={setIsStealthMode} isDarkLinkActive={isDarkLinkActive}>
        <div className="flex flex-col space-y-6 max-w-7xl mx-auto pb-12 transition-all duration-1000">
          
          <div className={`flex flex-col lg:flex-row items-stretch justify-between gap-4 glass p-4 rounded-2xl border-slate-800 shadow-2xl relative overflow-hidden ${defcon === 1 || isJamming ? 'defcon-alert' : ''}`}>
             <div className="flex flex-col md:flex-row items-center gap-6 z-20">
              <div className="flex flex-col min-w-[320px]">
                <span className="text-[10px] font-bold text-cyan-500 uppercase tracking-[0.2em] mb-2 px-1">Mission Control System</span>
                <div className="flex flex-wrap gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800/50">
                  {(['tactical', 'intelligence', 'lookup', 'interception', 'media', 'live', 'calculations', 'news', 'darklink'] as MainView[]).map((v) => (
                    <button
                      key={v}
                      onClick={() => setView(v)}
                      className={`px-3 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all duration-200 ${
                        view === v 
                          ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(34,211,238,0.3)]' 
                          : 'text-slate-400 hover:text-cyan-400 hover:bg-white/5'
                      }`}
                    >
                      {v === 'darklink' ? 'MESH / DARK' : v === 'calculations' ? 'CALCS' : v === 'interception' ? 'SIG_INTEL' : v === 'intelligence' ? 'SENTINEL' : v}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="h-12 w-px bg-slate-800 hidden md:block"></div>

              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2 px-1">Defcon Protocol</span>
                <div className="flex space-x-1.5 bg-slate-950/40 p-1 rounded-xl border border-slate-800/30">
                  {[5, 4, 3, 2, 1].map(lvl => (
                    <button key={lvl} onClick={() => setDefcon(lvl)} className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold transition-all border ${defcon === lvl ? (lvl <= 2 ? 'bg-red-500 text-white border-red-400' : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40') : 'bg-slate-900 border-slate-800 text-slate-600'}`}>
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-center lg:justify-end flex-grow z-20">
               <TelemetryPulse telemetry={telemetry} isStealthMode={isStealthMode} />
            </div>
          </div>

          <div className="min-h-[70vh]">
            {view === 'tactical' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in slide-in-from-bottom-4">
                <div className="lg:col-span-5 xl:col-span-4 space-y-6">
                  <TacticalHUD 
                    loc={userLoc} 
                    sat={selectedSat} 
                    satellites={satellites} 
                    onLocChange={setUserLoc} 
                    onSatChange={setSelectedSat} 
                    onSatellitesUpdate={setSatellites} 
                    isTracking={isTracking} 
                    onTrackingChange={setIsTracking} 
                    isJamming={isJamming} 
                    setIsJamming={setIsJamming} 
                    jammingPower={jammingPower} 
                    setJammingPower={setJammingPower} 
                    weather={weather} 
                    setWeather={setWeather} 
                    isStealthMode={isStealthMode}
                    telemetry={telemetry} 
                    eventLogs={eventLogs}
                    setEventLogs={setEventLogs}
                    hasNewLogs={hasNewLogs}
                    setHasNewLogs={setHasNewLogs}
                  />
                  <TacticalMap userLoc={userLoc} satellite={selectedSat} isTracking={isTracking} isStealthMode={isStealthMode} onLocChange={setUserLoc} />
                  {lookAngles && <LookAngleCard angles={lookAngles} satellite={selectedSat} />}
                  <SignalVisualizer quality={lookAngles?.elevation && lookAngles.elevation > 0 ? 85 : 0} isJamming={isJamming} jammingPower={jammingPower} rainFade={weather === 'CLEAR' ? 0.5 : 5.0} isStealthMode={isStealthMode} />
                </div>
                <div className="lg:col-span-7 xl:col-span-8">
                  <AITechnician 
                    context={{ lat: userLoc.lat, lng: userLoc.lng, satName: selectedSat.name, defcon, weather, isJamming }} 
                    telemetry={telemetry} 
                    isStealthMode={isStealthMode}
                    isNeuralCleaning={isNeuralCleaning}
                    onToggleNeuralCleaning={() => setIsNeuralCleaning(!isNeuralCleaning)}
                  />
                </div>
              </div>
            )}

            {view === 'intelligence' && (
              <SecurityTools 
                userLoc={userLoc} 
                selectedSatName={selectedSat.name} 
                isJamming={isJamming} 
                setIsJamming={setIsJamming} 
                jammingPower={jammingPower} 
                setJammingPower={setJammingPower} 
                signalQuality={88} 
                onBack={() => setView('tactical')} 
                isStealthMode={isStealthMode} 
                setIsStealthMode={setIsStealthMode} 
                addMissionLog={addMissionLog}
              />
            )}
            
            {view === 'interception' && (
              <SignalInterceptor isJamming={isJamming} jammingPower={jammingPower} isStealthMode={isStealthMode} />
            )}

            {view === 'media' && <MediaForge />}
            {view === 'live' && <LiveComms isStealthMode={isStealthMode} />}
            {view === 'lookup' && <SatelliteLookup initialLoc={userLoc} isStealthMode={isStealthMode} />}

            {view === 'calculations' && lookAngles && (
              <div className="max-w-4xl mx-auto space-y-6">
                <TerrainObstruction angles={lookAngles} />
                <LinkBudgetCalculator distance={lookAngles.distance} elevation={lookAngles.elevation} isStealthMode={isStealthMode} />
              </div>
            )}

            {view === 'news' && (
              <div className="max-w-4xl mx-auto">
                <RSSReader />
              </div>
            )}

            {view === 'darklink' && <DarkLink isActive={isDarkLinkActive} setIsActive={setIsDarkLinkActive} />}
          </div>
        </div>
      </Layout>
    </div>
  );
};

export default App;
